<?php $__env->startSection('page','Daftar Foto Produk'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="orders">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body d-flex justify-content-between">
						<h4 class="box-title">Daftar Foto Produk</h4>
						<a href="<?php echo e(route('product-galleries.create')); ?>" class="btn btn-outline-primary btn-sm">Tambah Foto</a>
					</div>
					<div class="card-body--">
						<div class="table-stats order-table ov-h">
							<table class="table ">
								<thead>
									<tr>
										<th>#</th>
										<th>Nama Barang</th>
										<th>Foto</th>
										<th>Default</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($item->product->name); ?></td>
										<td>
											<img src="<?php echo e(url($item->photo)); ?>" alt="" />
										</td>
										<td>
											<?php echo e($item->is_default ? 'Ya' : 'Tidak'); ?>

										</td>
										<td>
											<form action="<?php echo e(route('product-galleries.destroy', $item->id)); ?>" method="POST" class="d-inline">
												<?php echo method_field('DELETE'); ?>
												<?php echo csrf_field(); ?>

												<button class="btn btn-danger btn-sm">
													<i class="fa fa-trash"></i>
												</button>
											</form>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center p-5">
                                                Data Tidak Tersedia
                                            </td>
                                        </tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
                <?php echo e($items->links('vendor.pagination.semantic-ui')); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CaseStudy/BWALARAVUE/shayna-backend/resources/views/pages/product-galleries/index.blade.php ENDPATH**/ ?>