<?php if(Session::has('alert')): ?>
    <?php if(Session::get('alert')['type'] == 'success'): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('alert')['message']); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::get('alert')['type'] == 'error'): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('alert')['message']); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/html/CaseStudy/BWALARAVUE/shayna-backend/resources/views/includes/alert.blade.php ENDPATH**/ ?>