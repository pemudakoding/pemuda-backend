<?php $__env->startSection('page','Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="orders">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<h4 class="box-title">Daftar Transaksi Masuk</h4>
					</div>
					<div class="card-body--">
						<div class="table-stats order-table ov-h">
							<table class="table ">
								<thead>
									<tr>
										<th>#</th>
										<th>Name</th>
										<th>Email</th>
										<th>Nomor</th>
										<th>Total Transaksi</th>
										<th>Status</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($item->name); ?></td>
										<td><?php echo e($item->email); ?></td>
										<td><?php echo e($item->number); ?></td>
										<td>$<?php echo e($item->transaction_total); ?></td>
										<td>
											<?php if( $item->transaction_status === "PENDING" ): ?>
												<span class="badge badge-info">
											<?php elseif( $item->transaction_status === "SUCCESS" ): ?>
												<span class="badge badge-success">
											<?php elseif( $item->transaction_status === "FAILED" ): ?>
												<span class="badge badge-danger">
											<?php endif; ?>
													<?php echo e($item->transaction_status); ?>

												</span>
										</td>
										<td>

											<?php if($item->transaction_status == "PENDING"): ?>
												<a 	href="<?php echo e(route('transactions.status',$item->id)); ?>?status=SUCCESS"
													class="btn btn-success btn-sm">
													<i class="fa fa-check"></i>
												</a>
												<a 	href="<?php echo e(route('transactions.status',$item->id)); ?>?status=FAILED"
													class="btn btn-warning btn-sm">
													<i class="fa fa-times"></i>
												</a>
											<?php endif; ?>
											<a 	href="#transactionModal"
												class="btn btn-info btn-sm"
												data-remote='<?php echo e(route('transactions.show',['transaction' => $item->id])); ?>'
												data-toggle='modal'
												data-target='#transactionModal'
												data-title='Detail Transaksi <?php echo e($item->uuid); ?>'>
												<i class="fa fa-eye"></i>
											</a>
											<a href="<?php echo e(route('transactions.edit',['transaction' => $item->id])); ?>" class="btn btn-primary btn-sm">
												<i class="fa fa-pencil"></i>
											</a>
											<form action="<?php echo e(route('transactions.destroy',['transaction' => $item->id])); ?>" method="POST" class="d-inline">
												<?php echo method_field('DELETE'); ?>
												<?php echo csrf_field(); ?>

												<button class="btn btn-danger btn-sm">
													<i class="fa fa-trash"></i>
												</button>
											</form>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
										<tr>
											<td colspan="6" class="text-center p-5">
												Data Tidak Tersedia
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
                <?php echo e($items->links('vendor.pagination.semantic-ui')); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
	<script>
		jQuery(document).ready(function($){
			$('#transactionModal').on('show.bs.modal', function(e){
				let button = e.relatedTarget;
				let modal  = $(this)

				modal.find('.modal-body').load(button.dataset.remote);
				modal.find('.modal-title').html(button.dataset.title);
			});
		});
	</script>

	<!-- Modal -->
	<div class="modal fade" id="transactionModal" tabindex="-1" role="dialog"aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title"></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
			<i class="fa fa-spinner fa-spin"></i>
	      </div>
	    </div>
	  </div>
	</div>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CaseStudy/BWALARAVUE/shayna-backend/resources/views/pages/transaction/index.blade.php ENDPATH**/ ?>